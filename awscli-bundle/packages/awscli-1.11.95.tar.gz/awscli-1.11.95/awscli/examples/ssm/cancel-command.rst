**To attempt to cancel a command**

This example attempts to cancel a command. There is no output if the operation succeeds.

Command::

  aws ssm cancel-command --command-id "662add3d-5831-4a10-b64a-f2ff3a577858"
